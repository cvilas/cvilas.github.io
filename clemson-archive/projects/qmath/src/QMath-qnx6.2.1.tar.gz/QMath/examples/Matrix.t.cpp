//======================================================================== 
// Package		: The Math Library - Ex
// Authors		: Vilas Kumar Chitrakaran
// Start Date	: Wed Dec 20 11:08:28 GMT 2000
// Compiler		: GNU C++ 2.95.3 and above
// ----------------------------------------------------------------------
// File: Matrix.t.cpp
// Example program for the class Matrix.
//========================================================================

#include "Matrix.hpp"
#include "ColumnVector.hpp"
#include "RowVector.hpp" 

using namespace std;

//========================================================================
// This example demonstrates solving the foll. simultaneous eqns
// 2 * x1 + 8 * x2 + 5 * x3 = 5,
// 1 * x1 + 1 * x2 + 1 * x3 = -2,
// 1 * x1 + 2 * x2 - 1 * x3 = 2.
//========================================================================
int main()
{
 Matrix<3,3> A;
 ColumnVector<3> x;
 ColumnVector<3> b;

 // Write in Ax = b form
 A = 2, 8, 5,
     1, 1, 1, 
     1, 2, -1;
 b = 5, -2, 2;
 
 // solve for x
 x = inverse(A) * b;
 cout << "solution: " << transpose(x) << endl;

 return 0;
}
