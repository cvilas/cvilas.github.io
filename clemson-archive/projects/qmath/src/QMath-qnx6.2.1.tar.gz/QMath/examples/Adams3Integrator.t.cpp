//======================================================================== 
// Package		: The Math Library - Ex
// Authors		: Vilas Kumar Chitrakaran
// Start Date		: Wed Dec 20 11:08:28 GMT 2000
// Compiler		: GNU C++ 2.95.3 and above
// ----------------------------------------------------------------------
// File: Adams3Integrator.t.cpp
// Example program for the Integrator.
//========================================================================

//========================================================================
// Adams3Integrator.t.cpp
//------------------------------------------------------------------------
// Integrates a trignometric function using Adams method, and compares 
// result with analytical integration.
//========================================================================

#include "Adams3Integrator.hpp"
#include "ColumnVector.hpp"

#include <stdio.h>
#include <math.h>
#ifndef M_PI
 #define M_PI 3.14159265358979323846
#endif

int main()
{
 FILE *outfile;                           // File to store results
 double velocity;                         // some data
 double position_adams;                   // numerical integral
 double position_actual;                  // actual integral
 double initValue;                        // initial value of integration
 double sampling_period;                  // sampling period
 Adams3Integrator< double > myIntegrator; // numerical integrator

 outfile = fopen("Adams3Integrator.dat", "w+");
 initValue = 0;
 sampling_period = 0.001;
 
 myIntegrator.setSamplingPeriod(sampling_period);
 myIntegrator.reset(initValue);
 
 fprintf(outfile, "%s\n%s %s %s\n", "%Adams 3rd order integrator output file",
         "%velocity", "position_adams", "position_actual" );
 for (int i=0; i<1000; i++)
 {
  // input data
  velocity = sin(2*M_PI*i*sampling_period);
  
  // integrate
  position_adams = myIntegrator.integrate(velocity);
  position_actual = 1.0/(2*M_PI) * (1 - cos(2*M_PI*i*sampling_period));

  // simply write the outputs to a file... 
  fprintf(outfile, "%f %f %f\n", velocity, position_adams, position_actual);
 }
 
 fclose(outfile);
 return(0);
}
