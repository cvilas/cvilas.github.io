//======================================================================== 
// Package			: The Math Library - Ex
// Authors			: Vilas Kumar Chitrakaran
// Start Date		: Wed Dec 20 11:08:28 GMT 2000
// Compiler			: GNU C++ 2.95.3 and above
// ----------------------------------------------------------------------
// File: Differentiator.t.cpp
// Example program for the Differentiator.
//========================================================================

//========================================================================
//Differentiator.t.cpp
//------------------------------------------------------------------------
// Demonstration of Differentiator class. The numerical differentiation
// result is compared with analytical solution.
//========================================================================

#include "Differentiator.hpp"
#include "ColumnVector.hpp"
#include <stdio.h>

int main()
{
 FILE *outfile;  // This file holds the input and output waveforms.
 outfile = fopen("Differentiator.dat", "w+");
 
 double input;             // input signal
 double output_numerical;  // numerically computed derivative
 double output_actual;     // analytically computed derivative
 double error;             // error between numerical and analytical results
 double samplingPeriod;
 
 // Create Differentiator with a sampling period of 1 milli-second.
 samplingPeriod = 0.001;
 Differentiator<double> differentiator(samplingPeriod);
 
 // Set filter parameters.
 differentiator.setCutOffFrequencyHz(500);
 differentiator.setDampingRatio(1);
 differentiator.reset();

 fprintf(outfile, "%s\n%s %s %s %s\n", "%Differentiator output file",
         "%input", "output_actual", "output_numerical", "error" );
 for (int i = 0; i < 1.0/samplingPeriod; i++)
 {	
  input = cos(2*M_PI*i*samplingPeriod); // 1 Hz signal

  // Differentiate analytically and numerically
  output_actual = -(2 * M_PI) * sin(2*M_PI*i*samplingPeriod);
  output_numerical = differentiator.differentiate(input); 
  
  error = output_actual - output_numerical;
  
  // write the outputs to a file... 
  fprintf(outfile, "%f %f %f %f\n", input, output_actual, output_numerical, error);
 }
 fclose(outfile);
 return(0);
}


