//======================================================================== 
// Package			: The Math Library - Ex
// Authors			: Vilas Kumar Chitrakaran
// Start Date		: Wed Dec 20 11:08:28 GMT 2000
// Compiler			: GNU C++ 2.95.3 and above
// ----------------------------------------------------------------------
// File: Integrator.t.cpp
// Example program for the Integrator.
//========================================================================

//========================================================================
// Integrator.t.cpp
//------------------------------------------------------------------------
// Numerically integrates a time varying function and compares result
// with analytical solution
//========================================================================

#include "Integrator.hpp"
#include "ColumnVector.hpp"

#include <stdio.h>
#include <math.h>
#ifndef M_PI
 #define M_PI 3.14159265358979323846
#endif

int main()
{
 FILE *outfile;                           // File to store results
 double velocity;                         // some data
 double position_numerical;               // numerical integral
 double position_actual;                  // actual integral
 double error;
 double initValue;                        // initial value of integration
 double sampling_period;                  // sampling period
 Integrator< double > myIntegrator;       // numerical integrator

 outfile = fopen("Integrator.dat", "w+");
 initValue = 0;
 sampling_period = 0.001;
 
 myIntegrator.setSamplingPeriod(sampling_period);
 myIntegrator.reset(initValue);
 
 fprintf(outfile, "%s\n%s %s %s %s\n", "%Integrator output file",
         "%velocity", "position_actual", "position_numerical", "error" );
 for (int i=0; i<1000; i++)
 {
  // input data
  velocity = sin(2*M_PI*i*sampling_period);
  
  // integrate
  position_numerical = myIntegrator.integrate(velocity);
  position_actual = 1.0/(2*M_PI) * (1 - cos(2*M_PI*i*sampling_period));
  
  error = position_actual - position_numerical;

  // simply write the outputs to a file... 
  fprintf(outfile, "%f %f %f %f\n", velocity, position_actual, position_numerical, error);
 }
 
 fclose(outfile);
 return(0);
}



