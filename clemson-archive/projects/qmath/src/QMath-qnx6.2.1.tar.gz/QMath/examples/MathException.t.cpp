//======================================================================== 
// Package		: The Math Library - Ex
// Authors		: Vilas Kumar Chitrakaran
// Start Date		: Wed Dec 20 11:08:28 GMT 2000
// Compiler		: GNU C++ 2.95.3 and above
// ----------------------------------------------------------------------
// File: MathException.t.cpp
// Example program for the class MathExceptions.
//========================================================================  
 
#include "Matrix.hpp"

using namespace std;

int main()
{

 Matrix<2,2> m1, m2;

 m1 = 1.0, 5.6, 2.7, 8.4;
 
 // Enclose critical code inside try block.
 //subsequent catch block catches exceptions
 try
 {
  m2 = m1/0.0; /* divide by zero! */
 }
 catch (MathException &ex)
 {
  cout << ex.getErrorMessage() << endl;
  /* do exception recovery here */
  return -1;
 }
 cout << "This line won't print" << endl;
 return 0;
}
