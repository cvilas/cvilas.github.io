//======================================================================== 
// Package		: The Math Library - Ex
// Authors		: Vilas Kumar Chitrakaran
// Start Date	: Wed Dec 20 11:08:28 GMT 2000
// Compiler		: GNU C++ 2.95.3 and above
// ----------------------------------------------------------------------
// File: Vector.t.cpp
// Example program for the vector classes.
//========================================================================

#include "Vector.hpp"
#include "RowVector.hpp"

using namespace std;

int main()
{
 Vector<3> v1, v2, v3;
 
 v1 = 1, 1, 2;
 v2 = 2, 3, 4;
 double dp;
  
 // dot product: component of v1 along v2
 dp = dotProduct(v1, v2);
 cout << "Dot product: v1 . v2 = " << dp << endl;
 
 // cross product: v1 x v2
 v3 = crossProduct(v1, v2);
 cout << "Cross product: v1 x v2 = " << transpose(v3) << endl; 

 // 2-norm of a vector
 cout << "norm(v1): " << v1.norm() << endl;
 return 0;
}

